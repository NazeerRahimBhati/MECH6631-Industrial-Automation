
For high resolution monitors the window might be too large.
In that case use the following steps before running the image_view.exe
program:

1. Select the image_view.exe file

2. right click -> Properties -> Compatibility

3. check "Disable display scaling on high DPI settings"

4. Hit the Apply button
